(function($){
    window.x2 = window.x2 || {};
    x2.playerId = 'x2yun_' + $.now();
    x2.play = function(data){
        new xunleiLixianPlayerV2(data,{
            play : true,
            debug : false,
            mobile : false,
            autoPlay : true,
            container : 'player',
            player : x2.playerId,
            api : 'http://yundianbo.duapp.com/pz/url.php',
            callback : function(data){
                if(data.name){
                    nativeWindow.title = data.name;
                }
            },
            complete : function(){
                nativeWindow.close();
            },
            messager : function(type,msg){
                try{
                    window[x2.playerId].flv_setNoticeMsg(msg);
                }catch(ex){}
                if(type=='error'){
                    window.parent.alert(msg);
                }
            }
        });
    }
    x2.outputPlayer = function(){
        new xunleiLixianPlayerV2({},{
            swf: 'http://vod.lixian.xunlei.com/media/vodPlayer_2.8.swf?v=2.83.2',
            play : false,
            container : 'player',
            player : x2.playerId
        });
    }

    $(document).on('ready', function(){
        x2.outputPlayer();
        function resizeParent(e){
            window.parent.window.nativeWindow.x = nativeWindow.x - window.parent.window.nativeWindow.width;
            window.parent.window.nativeWindow.y = nativeWindow.y;
        }
        nativeWindow.addEventListener( air.NativeWindowBoundsEvent.MOVING, resizeParent);
        nativeWindow.addEventListener( air.NativeWindowBoundsEvent.RESIZING, resizeParent);
        nativeWindow.addEventListener( air.Event.ACTIVATE, function(){
            window.parent.window.nativeWindow.orderToFront();
        });
        nativeWindow.addEventListener( air.Event.CLOSING, function(){
            window.parent.window.playWindow = null;
        });
    });
})(jQuery);