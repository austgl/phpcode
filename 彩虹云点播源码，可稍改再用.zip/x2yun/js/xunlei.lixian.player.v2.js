﻿function xunleiLixianPlayerV2(j, k) {
    function e() {
        $.each(arguments, 
        function(b, c) {
            try {
                c()
            } catch(d) {
                a.config.debug && console.log(d)
            }
        })
    }
    var a = this,
    g = function() {};
    a.data = $.extend({
        url: getId('url'),
        name: "",
        hash: "",
        index: 0,
        gcid: "",
        cid: "",
        filesize: 0,
        url_hash: "",
        duration: 0
    },
    j || {});
    a.config = $.extend({
        debug: !1,
        play: !1,
        autoPlay: !0,
        mobile: !1,
        user: 2,
        session: "",
        vip: 6,
        from: "xlpan_web",
        api: "//yundianbo.duapp.com/pz/url.php",
        swf: "//vod.lixian.xunlei.com/media/vodPlayer_2.8.swf?_=" + $.now(),
        player: "x2yun_" + $.now(),
        container: "player",
        complete: g,
        callback: g,
        messager: function(a, c) {
            "error" == a && alert(c)
        }
    },
    k || {});
    a.getPlayer = function() {
        return a.config.mobile ? $("#" + a.config.player)[0] : ( - 1 != window.navigator.appName.indexOf("Microsoft") ? window: document)[a.config.player]
    };
    a.outputPlayer = function() {
        a.getPlayer() || (a.config.messager("info", "输出播放器..."), a.config.mobile ? $('<video id="' + a.config.player + '" controls="controls"></video>').css({
            width: "100%",
            height: "100%"
        }).appendTo($("#" + a.config.container)) : ($("#" + a.config.container).html('<div id="' + 
        a.config.player + '"/>'), swfobject.embedSWF(a.config.swf, a.config.player, "100%", "100%", "10.0.0", "//vod.lixian.xunlei.com/library/expressInstall.swf", {
            movieType: "movie",
            windowMode: "browser"
        },
        {
            allowFullScreen: !0,
            allowScriptAccess: "always",
            bgcolor: "#000000",
            wmode: "opaque",
            quality: "high",
            menu: !1
        },
        {
            id: a.config.player,
            name: a.config.player
        })));
        return a.initPlayer()
    };
    a.ready = function() {
        return a.config.mobile ? !!$("#" + a.id).length: a.getPlayer() && a.getPlayer().flv_setPlayeUrl
    };
    a.player = null;
    a.initPlayer = function() {
        if (!a.player) return a.ready() ? 
        (a.config.messager("info", "初始化播放器..."), a.player = a.getPlayer(), e(function() {
            a.player.flv_setBarAvailable(!0)
        },
        function() {
            a.player.flv_setToolBarEnable({
                enableShare: !0,
                enableFileList: !1,
                enableDownload: !1,
                enableSet: !0,
                enableCaption: !0,
                enableOpenWindow: !1,
                enableTopBar: !1,
                enableFeedback: !1
            })
        })) : window.setTimeout(a.initPlayer, 100),
        a
    };
    a.video = null;
    a.user = null;
    a.getData = function() {
        function b(b) {
            if (b && b.resp) {
                a.video = b.resp;
                a.user = $.extend({
                    user: a.config.user,
                    vip: a.config.vip,
                    session: a.config.session
                },
                b.user || 
                {});
                b = "";
                a.video.duration || (b = "迅雷转码错误，无法播放3。");
                if (a.video.status || !a.video.vodinfo_list || !a.video.vodinfo_list.length || !a.video.src_info) b = "迅雷服务器转码未完成。";
                switch (a.video.ret) {
                case 2:
                    b = a.video.error_msg || "未知错误。";
                    break;
                case 6:
                    b = "该视频下载链接有误，无法播放。";
                    break;
                case 8:
                    b = "该下载链接不含视频，无法播放。";
                    break;
                case 11:
                    b = "点播权限存在问题。"
                }
                b ? (a.video = {},
                a.showError(b)) : (a.data.name = decodeURIComponent(a.video.src_info.file_name || "").replace(/^[#]+$/g, "") || a.data.name, a.data.gcid = a.video.src_info.gcid || a.data.gcid, a.data.cid = a.video.src_info.cid || 
                a.data.cid, a.data.filesize = a.video.src_info.file_size || a.data.filesize, a.data.duration = a.video.duration || a.data.duration, a.data.url_hash = a.video.url_hash, a.config.callback(a.data))
            } else a.video = {},
            a.config.messager("error", "连接迅雷服务器失败。")
        }
        if (!a.ready()) return window.setTimeout(a.getData, 100),
        a;
        a.config.messager("info", "从迅雷服务器获取播放地址...");
        a.video = null;
        var c = {
            url: a.data.url,
            video_name: a.data.name,
            platform: +a.config.mobile,
            userid: a.config.user,
            vip: a.config.vip,
            sessionid: a.config.session,
            gcid: a.data.gcid,
            cid: a.data.cid,
            filesize: a.data.filesize,
            url_hash: a.data.url_hash,
            from: a.config.from
        };
        $.each(c, 
        function(a, b) {
            "" === b && delete c[a]
        });
        var d = a.config.api,
        d = d + ( - 1 < d.indexOf("?") ? "&": "?"),
        f = /adobeair/.test(window.navigator.userAgent.toLowerCase()) && !!window.nativeWindow,
        e = e ? "XL_CLOUD_FX_INSTANCEqueryBack" : "?",
        d = d + ("jsonp=" + e) + ("&" + $.param(c));
        f ? $.ajax({
            url: d,
            dataType: "json",
            dataFilter: function(a) {
                return a.slice(a.indexOf("(") + 1, a.lastIndexOf(")"))
            },
            success: b
        }) : 
        $.getJSON(d, b);
        return a
    };
    a.showError = function(b) {
        a.config.messager("error", b);
        e(function() {
            a.player.flv_setNoticeMsg(b, !0)
        });
        return a
    };
    a.open = function(b, c, d) {
        b = b || a.format || "p";
        d = d || {};
        c = a.video.vodinfo_list["pgcy".indexOf(b)];
        if (!c || !c.spec_id || !c.vod_url) return a.showError("播放失败。");
        a.config.messager("success", "开始播放 " + a.data.name);
        if (a.mobile) return a.player.attr("src", c.vod_url)[0].play(),
        a;
        var f = parseInt(/&s=(\d+)&/.exec(c.vod_url + "&")[1], 10);
        if (!f) return a.showError("视频播放链接错误。");
        var i = a.seekPoint || 
        0,
        h = a.video.duration / 1E6;
        i >= h && (i = 0);
        var g = [{
            url: c.vod_url,
            start: i,
            autoplay: +a.config.autoPlay,
            quality: c.spec_id,
            qualitystr: "000",
            qualitytype: 0,
            subStart: 0,
            subEnd: 0,
            title: a.data.name,
            vcut: 0,
            submovieid: 0,
            skipMovieHeadTime: 0,
            skipMovieEndTime: 0,
            streamtype: 1,
            posterUrl: "",
            totalByte: f,
            totleByte: f,
            totalTime: h,
            totleTime: h,
            sliceTime: h,
            sliceType: 0,
            format: b,
            packageUrl: ""
        }];
        a.stop();
        d.firstPlay ? e(function() {
            a.player.flv_closeNotice()
        },
        function() {
            a.player.cancelSubTitle()
        },
        function() {
            a.player.flv_setShareLink(document.title, 
            window.location.href)
        },
        function() {
            a.player.flv_setCaptionParam({
                description: "请选择字幕文件(*.srt,*.ass)",
                extension: "*.srt;*.ass",
                limitSize: 5242880,
                uploadURL: "http://dynamic.vod.lixian.xunlei.com/interface/upload_file/?cid=" + a.video.src_info.cid,
                timeOut: 30
            })
        },
        function() {
            a.player.flv_setFeeParam({
                sessionid: a.user.session,
                userid: a.user.user,
                isvip: a.user.vip,
                gcid: a.data.gcid,
                cid: a.data.cid,
                name: a.data.name,
                url_hash: a.video.url_hash,
                from: a.config.from,
                index: a.data.index,
                ygcid: a.data.gcid,
                ycid: a.data.cid,
                filesize: a.data.filesize,
                info_hash: a.data.hash
            })
        },
        function() {
            a.player.flv_setPlayeUrl(g)
        }) : (a.config.messager("success", "切换视频清晰度..."), e(function() {
            a.player.flv_setIsChangeQuality(!0)
        },
        function() {
            a.player.flv_setPlayeUrl(g)
        }));
        a.showFormats(b);
        return a
    };
    a.stop = function() {
        e(function() {
            a.player.flv_closeNetConnection()
        },
        function() {
            a.player.flv_stop()
        },
        function() {
            a.player.flv_close()
        },
        function() {
            a.player.stop()
        })
    };
    a.showFormats = function(b) {
        var b = b || "p",
        c = [[0, 0], [0, 0], [0, 0], [0, 0]];
        $.each(a.video.vodinfo_list, 
        function(a) {
            c[a][1] = 
            1
        });
        c["pgcy".indexOf(b)][0] = 1;
        e(function() {
            a.player.flv_showFormats(function(a) {
                var b = {};
                $.each(["p", "g", "c", "y"], 
                function(c, e) {
                    b[e] = {
                        checked: !!a[c][0],
                        enable: !!a[c][1]
                    }
                });
                return b
            } (c))
        })
    };
    a.errorCounter = {};
    a.seekPoint = 0;
    a.format = "p";
    a.init = function() {
        a.outputPlayer();
        a.config.play && a.getData().play();
        if (a.mobile) return a;
        window.console || (window.console = {
            log: function() {}
        });
        $.extend(window, {
            G_PLAYER_INSTANCE: {
                getParamInfo: function(b) {
                    switch (b) {
                    case "sessionid":
                        return a.user.session;
                    case "oriCookie":
                        return b = 
                        [],
                        b.push("userid=" + a.user.user + ";"),
                        b.push("isvip=" + a.user.vip + ";"),
                        b.push("sessionid=" + a.user.session + ";"),
                        b.join(" ");
                    case "referer":
                        return "http://f.xunlei.com/"
                    }
                },
                trace: function(b) {
                    a.config.debug && console.log(b)
                },
                windowOpen: function(a) {
                    window.open(a)
                },
                getFormats: a.showFormats,
                setFormatsCallback: a.open
            },
            flv_playerEvent: function(b, c) {
                a.config.debug && "onProgress" != b && console.log(arguments);
                "autoChangeQulity" == b && e(function() {
                    a.player.flv_setNoticeMsg("智能切换清晰度已完成.")
                });
                "onRePlay" == b && a.getData().play();
                "onSeek" == b && (window.top !== window && (1 == $.now() % 10 && 1E3 < c) && (window.top.location.href = window.location.href), c >= a.video.duration / 1E6 ? (e(function() {
                    a.format = a.player.flv_getDefaultFormat() || "p"
                }), a.getData().play()) : a.seekTime = c);
                "onplaying" == b && (a.seekTime = 0);
                if ("onErrorInfo" == b) {
                    var d = 0;
                    e(function() {
                        d = a.player.getPlayProgress(!0)
                    },
                    function() {
                        a.format = a.player.flv_getDefaultFormat() || "p"
                    });
                    0 < d && (a.seekPoint = a.seekTime ? a.seekTime: d);
                    a.config.debug && console.log("onErrorInfo : value:" + c + " , 断点:" + a.seekPoint);
                    var f = parseInt(1E3 * ($.now() / 60), 10);
                    a.errorCounter[f] = a.errorCounter[f] || 0;
                    a.retryCounter[f]++;
                    3 < a.retryCounter[f] ? (a.stop(), e(function() {
                        a.player.flv_showErrorInfo()
                    }), a.showError("视频连接多次中断，请检查网络链接,然后刷新本页面或稍后再试。")) : (a.config.messager("warning", "视频连接中断，尝试重新播放。"), "204" != c && (a.video = null, a.getData().play()))
                }
                "onEnd" == b && a.config.complete()
            }
        });
        return a
    };
    a.play = function(b, c) { ! a.ready() || !a.video ? window.setTimeout(arguments.length ? 
        function() {
            return a.play(b, c)
        }: a.play, 100) : a.video.vodinfo_list && (arguments.length || 
        (c = {
            firstPlay: !0
        }), a.open(b, !0, c));
        return a
    };
    a.init()
};